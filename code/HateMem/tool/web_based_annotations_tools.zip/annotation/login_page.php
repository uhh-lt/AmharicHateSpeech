
<!-- Coding By CodingNepal - youtube.com/codingnepal -->

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<?php 


      session_start();


    if(isset($_POST['Login']))
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
  
        move_uploaded_file($image_tmp,"images/$image");

        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");


        ############
        
        	$query 		= mysqli_query($con, "SELECT * FROM register WHERE  password='$password' and username='$username' and status='1'");
			$row		= mysqli_fetch_array($query);
			$num_row 	= mysqli_num_rows($query);
			
			if ($num_row > 0) 
				{			
					$_SESSION['username']= $username;
					setcookie($cookie_username, "set", time() + 120); // 2 minut
					
					if ($username=="mele" and $password=="1234"){
					    
                   echo "<script> window.location.assign('admin/index.php'); </script>";
					}else{
					    
                   echo "<script> window.location.assign('user/index.php'); </script>";
					}
				}
			else
				{
				    
				    
				        
                	$query = mysqli_query($con, "SELECT * FROM register WHERE  password='$password' and username='$username'");
        			$row = mysqli_fetch_array($query);
        			$num_row = mysqli_num_rows($query);
        			 if ($num_row > 0) {
        			    
                     $_SESSION['error'] = "It is not authenticated; please wait until it is.";
        			}else{
        			    
                     $_SESSION['error_danger'] = "Please Register before login";
        			}
				    
				    
			
				}
        ##########
    }
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Annotation Login Form | Multimodal Hate Speech Detection For Amharic Language</title>
    <link rel="stylesheet" href="style.css">
  </head>
  <body style ="background:white">
    <div class="center"   style ="background:silver">
      <h1>Multimodal Hate Speech Detection Login Form</h1>
      <form action="login_page.php" method="post" enctype="multipart/form-data"   style ="color:white">
          
      
          
          
          
  <?php
if(isset($_SESSION['error'])) {
?>

 <div class="alert alert-warning" role="alert">
 <?php
 echo $_SESSION['error'];
unset($_SESSION['error']); 
 ?>
</div>
<?php 
} 
?>   

  <?php
if(isset($_SESSION['error_danger'])) {
?>

 <div class="alert alert-danger" role="alert">
 <?php
 echo $_SESSION['error_danger'];
unset($_SESSION['error_danger']); 
 ?>
</div>
<?php 
} 
?>   


        <div class="txt_field">
          <input type="text" required name="username" style ="color:white">
          <span></span>
          <label style ="color:black">Username</label>
        </div>
        <div class="txt_field" style ="color:black">
          <input type="password" required name="password" style ="color:white">
          <span></span>
          <label style ="color:black">Password</label>
        </div>
        <div class="pass">Forgot Password?</div>
        <input type="submit" value="Login" name="Login">
        <div class="signup_link">
          Not a member? <a href="registration.html">Signup</a>
        </div>
      </form>
    </div>

  </body>
</html>

