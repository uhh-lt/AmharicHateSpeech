
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  


<?php 

    if(isset($_POST['Register']))
    {
        $id = $_POST['id'];

                
    $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

        
        $sql = " DELETE FROM register WHERE id = '$id'";
                if ($con->query($sql) === TRUE) {
                    echo "<script> window.location.assign('annotation_aprove.php'); </script>";
                    } 
                else {
                    echo "Error Inserting Data: " .$conn->error;
                }
                $conn->close();

    
    }
?>