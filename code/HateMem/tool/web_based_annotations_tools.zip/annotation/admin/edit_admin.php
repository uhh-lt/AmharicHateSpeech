
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  



<?php 

    if(isset($_POST['Register']))
    {
        $id = $_POST['id'];
        $username = $_POST['username'];
        $password = $_POST['password'];
        $address = $_POST['address'];
        $phone = $_POST['phone'];
        $status = 0;

    $conn = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

        
        //sql statement for checking if user exits
        $sql = "SELECT * FROM register WHERE id = '$id'";
        $result = mysqli_query($conn, $sql);
         $num=mysqli_num_rows($result);
        //check if result is 1 or 0
        if (!mysqli_num_rows($result)) {
          //username exists
          echo 'The username is already taken.'.mysqli_num_rows($result);
         echo "<script> window.location.assign('annotation_aprove.php'); </script>";
        } else {
         
                //Insert data into the database
                $sql = "UPDATE register SET username = '$username', phone='$phone', password='$password', address='$address' where id='$id'";
                
            
                        
                if ($conn->query($sql) === TRUE) {
                   echo "<script> window.location.assign('annotation_aprove.php'); </script>";
                    } 
                else {
                    echo "Error Inserting Data: " .$conn->error;
                }
                $conn->close();

    }
    }
?>