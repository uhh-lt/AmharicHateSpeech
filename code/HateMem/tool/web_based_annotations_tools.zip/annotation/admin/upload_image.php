
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  





<?php 


        $db = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

  
  
  
                                    $query = "SELECT * FROM dataset";
                                    $query_run = mysqli_query($db, $query);
                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $student)
                                        {
                                                $id=$student['id'];
                                        }
                                    }
                                    $orginal_id=$id;
                                                        
                                                

     
if(isset($_POST['upload'])){ 
    // File upload configuration 
    $targetDir = "image/"; 
    $allowTypes = array('jpg','JPG','PNG','png','JPEG','jpeg','gif'); 
     
    $statusMsg = $errorMsg = $insertValuesSQL = $errorUpload = $errorUploadType = ''; 
    $fileNames = array_filter($_FILES['files']['name']); 
    if(!empty($fileNames)){ 
        foreach($_FILES['files']['name'] as $key=>$val){ 
            // File upload path 
             $str = $_FILES['files']['name'][$key];
               
               
            $ch = "SELECT * FROM dataset where image_name='$str'";
            $query_runs = mysqli_query($db, $ch);
             if(mysqli_num_rows($query_runs) > 0)
                 {
                     $statusMsg.='<div class="alert alert-danger">The Image Already uploaded !</div>'.$errorMsg;
                     continue;
                 }
                       
               
               
            
                            $id=$id+1;
                            $a=explode(".",$str);
                            $aa=$id.".".$a[1];
                            
                            $fileName = basename($_FILES['files']['name'][$key]); 
                           // echo "file  == ".$_FILES['files']['name'][$key];
                            $targetFilePath = $targetDir . $aa; 
                             
                            // Check whether file type is valid 
                            $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION); 
                            if(in_array($fileType, $allowTypes)){ 
                                // Upload file to server 
                                if(move_uploaded_file($_FILES["files"]["tmp_name"][$key], $targetFilePath)){ 
                                    // Image db insert sql 
                                    $insertValuesSQL .= "('".$fileName."', NOW()),"; 
                                }else{ 
                                    $errorUpload .= $_FILES['files']['name'][$key].' | '; 
                                } 
                            }else{ 
                                $errorUploadType .= $_FILES['files']['name'][$key].' | '; 
                            } 
            
        } 
         
        // Error message 
        $errorUpload = !empty($errorUpload)?'Upload Error: '.trim($errorUpload, ' | '):''; 
        $errorUploadType = !empty($errorUploadType)?'File Type Error: '.trim($errorUploadType, ' | '):''; 
        $errorMsg = !empty($errorUpload)?'<br/>'.$errorUpload.'<br/>'.$errorUploadType:'<br/>'.$errorUploadType; 
         
        if(!empty($insertValuesSQL)){ 
            $insertValuesSQL = trim($insertValuesSQL, ','); 
            // Insert image file name into database 
            $insert = $db->query("INSERT INTO dataset (image_name, date) VALUES $insertValuesSQL"); 
            
                $statusMsg .= "Files are uploaded successfully.".$errorMsg; 
            if($insert){ 
              $statusMsg.='<div class="alert alert-success">Files are uploaded successfully</div>'.$errorMsg;
                
    $img_ref = rand();
            }else{ 
                $statusMsg.='<div class="alert alert-danger">Sorry, there was an error uploading your file.</div>';
            } 
        }else{ 
           
                $statusMsg.='<div class="alert alert-danger">Sorry,uploading failed.</div>'.$errorMsg; 
        } 
    }else{ 
        $statusMsg.='<div class="alert alert-danger">Please select a file to upload.</div>';
    } 
} 

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>Annotation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->




        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css"/>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>

    <style type="text/css">
            body{
                background: url(img/background.jpg);
                background-size: cover;
            }
            .wrapper{
                position: absolute;
                top: 15%;
                left: 50%;
                transform: translate(-50%);
                text-align: center;
                background-color: #ecf0f1;
                padding: 30px 20px;
                border-radius: 10px;
                box-shadow: 0px 0px 10px #000;
            }
            h4{
                margin-bottom: 50px;    
            }
            input{
                width: 100%;
            }
            input[type="submit"]{
                background-color: #00B594;
                color: #fff;
                border: none;
                border-radius: 5px;
                padding: 5px 0;
            }
            input[type="submit"]:hover{
                background-color: #4A566E;
            }
            .images-display{
                display: flex;
                justify-content: space-around;
                padding: 10px;
                margin-bottom: 20px;
                border: 1px solid #9A9A9A;
                border-radius: 5px;
            }
            .name p{
                width: 100%;
                font-size: 18px;
            }
            .images-display img{
                width: 110px;
                height: 100px;
                object-fit: cover;
            }
        </style>






  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
               <li class="nav-item">
                <a class="nav-link" href="index.php">Home
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" href="upload_image.php">Upload Dataset</a>
                  <span class="sr-only">(current)</span>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="annotation_aprove.php">Annotator Managment</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
          
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        <section class="wrapper" style="margin:10px">
        
        <h4>Upload Multiple Images Using PHP and MySql</h4>


        <div class="name">
            <?php
                if (isset($_GET['name'])) {
                    echo "<p>Thank You ".ucfirst($_GET['name'])."</p>"; 
                } 
            ?>
        </div>
          
        <div>
            <?php 
            echo $statusMsg;
            ?>
        </div>
        
        <div class="images-display">
            <?php
                if (isset($img_ref)) {
                    
            
            // Include the database configuration file
  $db = mysqli_connect("localhost","id20095711_root","meleAyi@1212","id20095711_kalaiphpforms");

            // Get images from the database

            $orginal_id=$orginal_id+1;
            
            
            
            
            
                	$sql="select * from dataset where date=NOW()";
                	$rs_result = mysqli_query($db, $sql);
                    foreach($rs_result as $student)
                     {
                            $ex=$student['image_name'];
                            $id_ex=$student['id'];
                            $a=explode(".",$ex);
                            $aa=$id_ex.".".$a[1];
                    
                 $imageURL = 'image/'.$aa;
                ?>
                    <img src="<?php echo $imageURL;?>" alt="" />
                
                    
                <?php 
            } 

                }else{
                    echo '<img src="img/photo.png">
                            <img src="img/photo.png">
                            <img src="img/photo.png">
                            <img src="img/photo.png">';
                }
                
                
                
            ?>          
        </div>
        
        <form action="" method="POST" enctype="multipart/form-data">
            
            <input type="file" name="files[]" multiple>
            <br><br>
            <input type="submit" name="upload" value="Upload">

        </form> 

        <?php
            if (isset($errorMsg)) {
                
                echo $errorMsg;
            }
            elseif (isset($statusMsg)) {
                
                echo "<span style='color:green;'>$statusMsg</span>";
                header("Refresh: 5; url=upload_image.php");
            }
        ?>

    </section> <!-- /End of wrapper section -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    <section class="call-to-action">
      <div class="container">
        <div class="row">
   
        </div>
      </div>
    </section>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2022 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>



