
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  



<?php
if(isset($_POST["save"])) {
  #########
  echo "dd";
   $filename = $_FILES["image"]["name"];
    $tempname = $_FILES["image"]["tmp_name"];
    $folder = "./image/" . $filename;
 
        $db = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
 
    // Get all the submitted data from the form
    $sql = "INSERT INTO dataset (image_name) VALUES ('$filename')";
 
    // Execute query
   $result= mysqli_query($db, $sql);
   if(!$result){
       echo "hhh";
       echo $result;
   }
   else{
       
        // Now let's move the uploaded image into the folder: image
    if (move_uploaded_file($tempname, $folder)) {
        echo "<h3>  Image uploaded successfully!</h3>";
    } else {
        echo "<h3>  Failed to upload image!</h3>";
    }
  
  
       
   }
 
   
  
  ##########


}
?>

