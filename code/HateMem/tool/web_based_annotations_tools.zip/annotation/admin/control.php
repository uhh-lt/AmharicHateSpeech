
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  

<?php

    $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

       
if(!empty($_GET['status_id'])&&isset($_GET['status_id']))
		{
			$status_id = $_GET['status_id'];
			$status = $_GET['status'];
			if($status==0){
			    $status=1;
			}else{
			    $status=0;
			}
			$query = "UPDATE register SET status = '$status' WHERE id = '$status_id'";
                   mysqli_query($con, $query);
		header("location:annotation_aprove.php");
		}
?>
