

  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
$username = $_SESSION['username'];
?>  

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <?php include 'includes/header.php' ?>

    <title>Annotation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">
    
    
    
    
<!-- jQuery -->
    
    
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    
    
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link" href="index.php">Home
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="upload_image.php">Upload Dataset</a>
              </li>
              <li class="nav-item">
                    <a class="nav-link active" href="annotation_aprove.php">Annotator Managment
                
                  <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
   
    </div>
    
    <!-- Banner Ends Here -->










<!-- The Modal   add-->
<div class="modal" id="myModal" style="margin:100px;">
  <div class="modal-dialog">
    <div class="modal-content" style="padding:10px;">
        
        <form action="registration_admin.php" method="post">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Add Annotator</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
     
        <div class="txt_field">
          <label style ="color:black">Username</label>
          <input type="text" required name="username"  class="form-control" style ="color:black">
          <span></span>
        </div>
        
        
        <div class="txt_field">
          <label style ="color:black">Address</label>
          <input type="text" required name="address"  class="form-control" style ="color:black">
          <span></span>
        </div>
        
        
        
        
        <div class="txt_field">
          <label style ="color:black">Phone(+2519XXXXXXXX)</label>
          <input type="text" required name="phone" class="form-control" pattern="\+251\d{9}" title="only format is +2519xxxxxxxx example +251910101010">
          <span></span>
        </div>
        
        
        <div class="txt_field" style ="color:black">
          <label style ="color:black">Password</label>
          <input type="password" class="form-control" name="password" id="password"  required style ="color:black" pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}$" title="title must be contain digit and charactor and minimum 6 ">
          <span></span>
        </div>
        
        
        <div class="txt_field" style ="color:black">
          <label style ="color:black">Confirm Password</label>
          <input type="password" class="form-control" name="confirm_password" id="confirm_password"  required  pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}$" title="title must be contain digit and charactor and minimum 6 ">
          <span></span>
        </div>
        
        <br>
        
      
        <input type="submit" value="Register" name="Register" class="btn btn-success" onclick="validatePasswords()">
        </form>
        
      <!-- Modal footer 
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      </div>
-->
    </div>
  </div>
</div>




 <script type="text/javascript">

  $(document).ready(function(){

   $(document).on('click', '.edit', function(){


 
 
    var id=  $(this).closest('tr').find('#id').text();// get firstname
    var username=  $(this).closest('tr').find('#username').text();// get firstname
    var address=  $(this).closest('tr').find('#address').text(); // get lastname
    var phone=  $(this).closest('tr').find('#phone').text(); //get address
    var password=  $(this).closest('tr').find('#password').text(); //get address
    
    $('#edited').modal('show');//load modal
    
    
    $('#edit-id').val(id);
    $('#edit-username').val(username);
    $('#edit-address').val(address);
    $('#edit-phone').val(phone);
    $('#edit-password').val(password);


   });

  });

 </script>





<!-- The Modal   edit-->
<div class="modal" id="edited" style="margin:100px;">
  <div class="modal-dialog">
    <div class="modal-content" style="padding:10px;">
        
        <form action="edit_admin.php" method="post">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Edit Annotator</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
         
        <div class="txt_field">
          <label style ="color:black">ID</label>
          <input type="text" required name="id" id="edit-id"  class="form-control" style ="color:black" readonly>
          <span></span>
        </div>
        
        <div class="txt_field">
          <label style ="color:black">Username</label>
          <input type="text" required name="username" id="edit-username"  class="form-control" style ="color:black">
          <span></span>
        </div>
        <div class="txt_field">
          <label style ="color:black">Address</label>
          <input type="text" required id="edit-address" name="address"  class="form-control" style ="color:black">
          <span></span>
        </div>
        
        <div class="txt_field">
          <label style ="color:black">Phone(+2519XXXXXXXX)</label>
          <input type="text" required name="phone" id="edit-phone" class="form-control" pattern="\+251\d{9}" title="only format is +2519xxxxxxxx example +251910101010">
          <span></span>
        </div>
        
        
        <div class="txt_field" style ="color:black">
          <label style ="color:black">Password</label>
          <input type="text" class="form-control" name="password" id="edit-password"  required style ="color:black" pattern="(?=.*\d)(?=.*[a-zA-Z]).{6,}$" title="title must be contain digit and charactor and minimum 6 ">
          <span></span>
        </div>
        <br>
        
        <input type="submit" value="Edit" name="Register" class="btn btn-primary" onclick="validatePasswords()">
        </form>
    </div>
  </div>
</div>














 <script type="text/javascript">

  $(document).ready(function(){

   $(document).on('click', '.delete', function(){


 
 
    var id=  $(this).closest('tr').find('#id').text();// get firstname
    
    $('#delete').modal('show');//load modal
    
    
    $('#delete-id').val(id);


   });

  });

 </script>
 

<!-- The Modal   delete-->
<div class="modal" id="delete" style="margin:100px;">
  <div class="modal-dialog">
    <div class="modal-content" style="padding:10px;">
        <form action="delete_admin.php" method="post">
          <div class="modal-header">
            <h4 class="modal-title">Delete Annotator</h4>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="txt_field">
              <label style ="color:black">Are you sure to delete this Person</label>
              <input type="text" required name="id" id="delete-id"  class="form-control" style ="color:black" readonly>
              <span></span>
          </div>
          <br>
           <input type="submit" value="Delete" name="Register" class="btn btn-danger" onclick="validatePasswords()">
        </form>
    </div>
  </div>
</div>

























    
















    


    <section class="blog-posts grid-system" style="margin-top:-1px;">
         <div class="container mt-4">

        <?php include('message.php'); ?>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Annotator Managment 
                           
                                            
                            <button type="button" class="btn btn-primary float-end" style="margin-top:10px;" data-bs-toggle="modal" data-bs-target="#myModal">
                                Add Annotator
                              </button>
                            
                            </h4>
                    </div>
                    <div class="card-body">

                        <table  id="data_table" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User Name</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Password</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            
                            <tbody>
                                <?php 
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");


                                    $query = "SELECT * FROM register";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $student)
                                        {
                                            ?>
                                            <tr>
                                                <td id="id"><?= $student['id']; ?></td>
                                                <td id="username"><?= $student['username']; ?></td>
                                                <td id="phone"><?= $student['phone']; ?></td>
                                                <td id="address"><?= $student['address']; ?></td>
                                                
                                                <td id="password"><?php  echo "***************"; ?></td>
                                                <td>
                                                    
                                           <?php
                                           
                                           if ($student['username'] == $username){
                                             
                                             ?>
                                                                                                 
                    <button type="button" class="btn btn-success" value="Approve" disable>
                                <span> Approve &nbsp&nbsp&nbsp</span>
                              </button>
                                             <?php
                                           }else{
                                           if($student['status']==0){?>
                                           
                                                                                   
               <a href="control.php?status_id=<?php echo $student['id'];?>&status=<?php echo $student['status'];?>"  class="btn btn-success" style="padding-right:20px;padding-left:20px;">Approve
                	</a>
                                           
                                               <?php
                                           }else{
                                               ?>
                                                                                       
               <a href="control.php?status_id=<?php echo $student['id'];?>&status=<?php echo $student['status'];?>"  class="btn btn-warning">disapprove
                	</a>
                                               <?php
                                           }
                                           }
                                           
                                           ?>
              

        
        
        
        
          <button type="button" class="btn btn-primary edit" value="<?php echo $student['id']; ?>">
                                <span class="glyphicon glyphicon-edit"></span>
                              </button>
                              <?php
                              $usernameee =$student['username'];
                                 $dd = "SELECT * FROM  annotate_data where username = '$usernameee'";
                                    $ll = mysqli_query($con, $dd);

                                    if(mysqli_num_rows($ll) > 0)
                                    { 
                                    
                                    ?>
                                       <button type="button" class="btn btn-danger delete" value="<?php echo $student['id']; ?>" disabled>
                                <span class="glyphicon glyphicon-danger">Delete</span>
                              </button>
                                    <?php
                                        
                                    }else{
                                    
                                        
                                           if ($student['username'] == $username){
                                               ?>
                                                <button type="button" class="btn btn-danger delete" value="<?php echo $student['id']; ?>" disabled>
                                <span class="glyphicon glyphicon-danger">Admin</span>
                              </button>
                                        
                                               <?php
                                           }else{
                                               ?>
                                                <button type="button" class="btn btn-danger delete" value="<?php echo $student['id']; ?>" >
                                <span class="glyphicon glyphicon-danger">Delete</span>
                              </button>
                                        
                                               <?php
                                           }
                                    
                                    
                                    ?>
                                          
                                        
                                        <?php
                                    }
                              
                              ?>
                             
          
       
                              
                       
        
                                                      
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
  
    </section>
    

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2022 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }




</script>

  </body>

</html>
