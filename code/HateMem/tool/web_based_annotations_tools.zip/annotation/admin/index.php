
  <?php
  session_start();
  

if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
$username = $_SESSION['username'];
?>  

<!DOCTYPE html>
<html lang="en">


  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    

    <title>Annotation Page</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">



  </head>






  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="upload_image.php">Upload Dataset</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="annotation_aprove.php">Annotator Managment</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
  
      </section>
    </div>
    


    <section class="blog-posts grid-system">
      <div class="container" style="margin-top:-270px;">

               <p>
        <a href="report_generate.php" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-print"></span> Generate all report
        </a>
        
        
                    
            <?php
              if(isset($_POST['majority_voting'])){
                  
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

                   $qu = "SELECT * FROM dataset where annotator_one='a' or annotator_two ='a' or annotator_three='a'";
                                    $qu_rn = mysqli_query($con, $qu);
                                    $total_number_of_dat=mysqli_num_rows($qu_rn) ;
                                
                  
                  
                  
                  if($total_number_of_dat>0){
                      echo "<script>alert('Please annotate all data .. you have remaning . $total_number_of_dat');</script>";
                  }else{
            

                                    $auto_annotate = "SELECT DISTINCT image_id FROM annotate_data ORDER BY image_id ASC";
                                     
                                    $auto_annotate_query = mysqli_query($con, $auto_annotate);
                                    $auto_annotate_query_total=mysqli_num_rows($auto_annotate_query) ;
                                  
                                    
                                    if($auto_annotate_query_total > 0)
                                    { 
                                        foreach($auto_annotate_query as $images_ids)
                                        {
                                            $images_id=$images_ids['image_id'];
                                            
                                            
                                            
                                                $gg = "SELECT * FROM annotate_data where image_id=$images_id";
                                                $hh = mysqli_query($con, $gg);
                                                if(mysqli_num_rows($hh) > 0)
                                                {
                                                    $hate=0;
                                                    $nothate=0;
                                                    foreach($hh as $pp)
                                                    {
                                                        if($pp[lable]=="hate speech")
                                                        {
                                                            $hate=$hate+1;
                                                        }else{
                                                            $nothate=$nothate+1; 
                                                        }
                                                        
                                                    }

                                                        if($hate>$nothate){
                                                            $queryhh = "UPDATE annotate_data SET majority_voting = 'hate speech'   where image_id=$images_id";
                                                            mysqli_query($con, $queryhh);
                                                            $sucess="seccessfully annotate majority voting";
                                                        }else{
                                                            
                                                            
                                                        }

                                                }
                                            
                                            
                                            
                                        }
                                        
                                    echo '<div class="alert alert-success">Seccessfully Annotate Majority Voting </div>';
                                    }
                                    
              }
              }
                                    ?>
                                    
                                    
                                    <?php
                                    if (isset($_POST['button'])) {
                                        // If the button with the name "button" is pressed
                                    
                                        // Check if the input field with the name "input" is empty
                                        if (empty($_POST['input'])) {
                                            // If it's empty, display an error message
                                            echo "Please enter a value in the input field";
                                        } else {
                                            // If it's not empty, display a success message
                                            echo "Success! The input field contains: " . $_POST['input'];
                                        }
                                    }
                                    ?>
            
          <form action="" method="POST">
            <input type="submit" class="btn btn-info btn-lg" name="majority_voting" value="Applay Majority Voting to Automatically Annotate ">

          </form>
        
        
        
      </p> 
         <p>All information About the annotation:      </p> 
      <?php 
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
                                    

                                    $queryy = "SELECT * FROM dataset";
                                    $query_runn = mysqli_query($con, $queryy);
                                    $total_number_of_dataset=mysqli_num_rows($query_runn) ;
                                
                                    
                                    
                                    ?>
      
      
            <table id="examplee" class="table table-striped table-bordered" style="width:100%">
              <thead>
                <tr>
                  <th>User Name</th>
                  <th>Phone</th>
                  <th>Address</th>
                  <th>Satus</th>
                  <th>Total Dataset</th>
                  <th>Annotated data</th>
                  <th>Remaning Data</th>
                  <th>Percent</th>
                  <th>Total Payment </th>
                </tr>
              </thead>
              
              
              
              
               <tbody>
                                <?php 
                                  

                                    $query = "SELECT * FROM register";
                                    $query_run = mysqli_query($con, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $student)
                                        {
                                            ?>
                                            <tr>
                                                
                                                <?php
                                                $usrnm=$student['username'];
                                                $single_birr=$student['single_birr'];
                                                
                                    $queryys = "SELECT * FROM annotate_data where username='$usrnm'";
                                    $query_runns = mysqli_query($con, $queryys);
                                    $total_number_of_annotated_dataset=mysqli_num_rows($query_runns) ;
                                    if ($total_number_of_annotated_dataset =="")
                                    {
                                        
                                       $total_number_of_annotated_dataset=0;
                                    }

                                    $remaning= $total_number_of_dataset-$total_number_of_annotated_dataset;
                                    
                                   $works_in_percent =$total_number_of_annotated_dataset/$total_number_of_dataset*100;
                                   if($student['status'] ==0){
                                       $stts="Deactive";
                                   }else{
                                       $stts ="Active";
                                   }
                                                ?>
                                                <td><?= $student['username']; ?></td>
                                                <td><?= $student['phone']; ?></td>
                                                <td><?= $student['address']; ?></td>
                                                <td><?= $stts; ?></td>
                                                <td><?= $total_number_of_dataset; ?></td>
                                                <td><?= $total_number_of_annotated_dataset; ?></td>
                                                <td><?= $remaning; ?></td>
                                                <td><?= $works_in_percent."%"; ?></td>
                                                <td><?= $total_number_of_annotated_dataset*$single_birr; ?></td>
                                              
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5> No Record Found </h5>";
                                    }
                                ?>
                                
                            </tbody>
                            
                            
                            
                            
                       
            </table>




        </div>
    </section>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2022 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript
 -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


  
    
    
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>

  

  </body>

</html>
