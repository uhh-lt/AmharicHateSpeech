
  <?php
  session_start();
if(isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page
} else {
     echo "<script> window.location.assign('../login_page.php'); </script>";
}
?>  


<style>
    
    .responsive-image {
   max-width: 450px;
   max-height: 300px;
   width: auto;
   height: auto;
}

</style>


<script>
    window.onload = function() {
        var imageElement = document.getElementById("imageId");
        window.scrollTo(0, imageElement.offsetTop);
    }
</script>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>
    <title>Annotation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link " href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link active" href="guidline.php">Guidline</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
                     
                <h4 class="alert alert-success">Dataset Annotation Guideline.(ዳታሴት ማብራሪያ መመሪያ።)</h4> 
                <h5 style="color:black;" hidden>Before start to annotation,  you must be understand how to annotate and understand the instraction.</h5>
                <p style="color:black;" hidden><strong >
                    
                    Guideline for annotators: this guideline is written English language with
                    hate-speech examples on the website which is developed for only annotation purposes.
                    The dataset annotation guidelines and conventions that will be used by annotators are
                    written as follows. This guideline will be used to make the annotator focusing area as clear
                    as possible while analyzing the context of images and content of the images.
                    The images are taken from different social media sources such as Twitter, Facebook and
                    telegram.
                    First, based on the message, you have to decide if the image is a hate speech, or Normal
                    speech.
                    Please read the task definitions carefully and try to understand the examples given.
                    <br>
                    <br></strong>
                    </p>
                    <p style="color:black;"></p>
                    <span class="underlined" class="alert alert-sucess"><bold class="alert alert-info"><strong style="size:30px;">በአማርኛ</strong> </bold></span>
                    <br>
                    <p style="color:black;" class="alert alert-info"><bold>
                    ማብራሪያውን ከመጀመርዎ በፊት ማብራሪያውን እንዴት መግለፅ እና መምረጥ እንዳለቦት መረዳት አለብዎት። <br>
የአኖቴተሮች መመሪያ፡-  ይህ መመሪያ በድረ-ገጹ ላይ የጥላቻ ንግግር ምሳሌዎችን የያዘ የአማረኛ ቋንቋ ለማብራራት ብቻ የተዘጋጀ ነው። የመረጃ ቋት ማብራሪያ መመሪያዎች እና የውል ስምምነቶች በአኖቴተሮች የሚጠቀሙባቸው እንደሚከተለው ተጽፈዋል። ይህ መመሪያ የምስሎችን እና የምስሎችን ይዘት አውድ እየተነተነ ገላጭ የትኩረት ቦታን በተቻለ መጠን ግልጽ ለማድረግ ይጠቅማል። ምስሎቹ ከተለያዩ የማህበራዊ ሚዲያ ምንጮች እንደ ትዊተር፣ ፌስቡክ እና ቴሌግራም የተወሰዱ ናቸው። በመጀመሪያ, በመልእክቱ ላይ በመመስረት, ምስሉ የጥላቻ ንግግር ወይም መደበኛ ንግግር መሆኑን መወሰን አለብዎት. እባክዎ የተግባር መግለጫዎችን በጥንቃቄ ያንብቡ እና የተሰጡትን ምሳሌዎች ለመረዳት ይሞክሩ።

                    
                    </bold>
                </p>
                <h3 hidden>Definitions </h3>
                
               <p style="color:black;" hidden><strong> Speech means the act of disseminating of information verbally, textually, graphically or
                by other means;Hate speech is a language used to express hatred towards a targeted individual or group, or is intended to be derogatory, to humiliate, or to insult the members of the group, on
                the basis of attributes such as race, religion, ethnic origin, sexual orientation, disability,
                or gender.
                </strong></p>
               <p style="color:black;"hidden><strong> It is NOT the presence of certain words that makes the text hate speech, rather you should
                look at the context the word is used in the text.
                </strong></p>
             <p style="color:black;"hidden><strong>According to federal negarit gazeta “Hate speech” means speech that deliberately
                promotes hatred, discrimination or attack against a person or an discernable group of
                identity , based on ethnicity, religion, race, gender or disability;
                A speech is a Hate speech if: 
                </strong></p>
                <p style="color:black;"hidden><strong>
                    When the target involved is either a general group of individuals who share a
                common characteristic or language directed towards a specific individual or entity
                    
            
                  
                  <p style="color:black;"hidden><strong>If the text is capable of spreading, inciting and promoting violence against a target
                it makes use of disparaging terms with the intent to harm or incite harm
                </strong></p>
                <p style="color:black;"hidden><strong>  It refers to and supports other hateful facts, hate tweets and organization
                </strong></p>
                 <p style="color:black;"hidden><strong> It makes use of idiomatic, metaphorical, collocation or any other indirect means of
                expressions that are harmful or may incite harm
                </strong></p>
                 <p style="color:black;"hidden><strong> It expresses violent communications
                </strong></p>
                 <p style="color:black;"hidden><strong> It uses derogatory or racial slur words within the text
                </strong></p>
                  <p style="color:black;"hidden><strong>It makes use of disparaging terms with the intent to harm or incite harm
                </strong></p>
                  <p style="color:black;"hidden><strong>It refers to and supports other hateful facts, hate tweets and organization
                </strong></p>
                 <p style="color:black;"hidden><strong> It makes use of idiomatic, metaphorical, collocation or any other indirect means of
                expressions that are harmful or may incite harm
                </strong></p>
                 <p style="color:black;"hidden><strong> It expresses violent communications
                </strong></p>
                  <p style="color:black;"hidden><strong>Uses a sexist or racial slur.
                </strong></p>
                 <p style="color:black;"hidden><strong> Attacks a minority.
                </strong></p>
                 <p style="color:black;"hidden><strong> Seeks to silence a minority or other race or religion.
                </strong></p>
                  <p style="color:black;"hidden><strong>Criticizes a minority (without a well-founded argument).
                </strong></p>
                 <p style="color:black;"hidden><strong> Promotes, but does not directly use, hate speech or violent crime.
                </strong></p>
                 <p style="color:black;"hidden><strong> Criticizes a minority and uses a straw man argument.
                </strong></p>
                 <p style="color:black;"hidden><strong> Blatantly misrepresents truth or seeks to distort views on a minority with unfounded claims.</strong></p>
                  <p style="color:black;"><strong></strong></p>
                  
                  
                 <p style="color:black; align:justify;"><br><br>
                     
                     <div class="alert alert-success">
                         
                         <p class="alert alert-sucess"> <strong> ፍቺዎች</strong> </p>
                     </div>
                     <br>
                     <div class="alert alert-info">
 
  </p>
     <p>
     

 
 <strong>ንግግር</strong> ማለት መረጃን በቃላት ፣በፅሁፍ ፣በግራፊክ ወይም በሌላ መንገድ የማሰራጨት ተግባር ማለት ነው ።<br>
<strong>የጥላቻ  </strong>ማለት ለታለመ ግለሰብ ወይም ቡድን ጥላቻን ለመግለጽ የሚያገለግል ቋንቋ ነው ፣ወይንም ለማንቋሸሽ ፣ለማዋረድ ፣ወይም አባላትን ለመሳደብ የታሰበ ቋንቋ ነው። ቡድኑ እንደ ዘር፣ ሃይማኖት፣ የዘር ምንጭ፣ ጾታዊ ዝንባሌ፣ አካል ጉዳተኝነት ወይም ጾታ ባሉ ባህሪያት ላይ በመመስረት ስዎችን ያንኮስሳል።<br>
                        
<br>
<strong>ጥላቻ-አልባ ንግግር</strong>
 : ጥላቻ-አልባ ንግግር ከሆነ ጥላቻ እንደሌለው ይቆጠራል
ምንም ዓይነት ተገቢ ያልሆነ ግንዛቤን አይገልጽም እና
አዎንታዊ ስሜቶችን ያስተላልፋል (ማለትም፣ ፍቅር፣ ምስጋና፣
ድጋፍ ፣ እና ተነሳሽነት) በግልፅ ወይም በተዘዋዋሪ።
<br>

<strong>የጥላቻ ንግግር ማለት </strong> ጽሑፉን ወይም ስእሉን እንዲጠላ ያደረገው የተወሰኑ ቃላት መኖራቸው ወይም ስእል መኖሩ ሳይሆን በቃሉ እና በስእሉ ውስጥ ጥቅም ላይ የዋለውን አውድ መመልከት አለብህ።<br>

<strong> የጥለቻ ንግግር </strong> የተለያየ ትርጉም ሲኖረው ከነዚህም ውስጥ የሚከተሉት በዚህ መልኩ አብራርተውታል<br>
<strong> በፌዴራል ነጋሪት ጋዜጣ "የጥላቻ ንግግር" </strong> ማለት ሆን ብሎ ጥላቻን፣ አድልዎ ወይም ጥቃትን በብሔር፣ በሃይማኖት፣ በዘር፣ በጾታ ወይም በአካል ጉዳተኝነት ላይ በመመስረት በአንድ ሰው ወይም በሚታወቅ የማንነት ቡድን ላይ የሚያበረታታ ንግግር ነው።<br>
<strong> ንግግሩ የጥላቻ ንግግር ከሆነ የሚከተሉት ባህሪያት አሉት፡-</strong> <br>
<strong> 1) </strong> የሚመለከተው ዒላማ አንድ የጋራ ባህሪ የሚጋሩ የግለሰቦች አጠቃላይ ቡድን ወይም ወደ አንድ የተወሰነ ግለሰብ ወይም አካል የሚመራ ቋንቋ ከሆነ<br>

<strong> 2) </strong>  ጽሑፉ በዒላማው ላይ ጥቃትን ማሰራጨት ፣ ማነሳሳት እና ማስተዋወቅ የሚችል ከሆነ ለመጉዳት ወይም ለመጉዳት በማሰብ የማጥላላት ቃላትን ይጠቀማል ።<br>
<strong> 3) </strong> ሌሎች የጥላቻ እውነታዎችን፣ የጥላቻ ትዊቶችን እና ድርጅትን ይመለከታል እና ይደግፋል<br>
<strong> 4) </strong> ፈሊጣዊ፣ ዘይቤያዊ፣ መሰባበር ወይም ሌሎች ጎጂ ወይም ጉዳት ሊያደርሱ የሚችሉ ሌሎች ቀጥተኛ ያልሆኑ አገላለጾችን ይጠቀማል።<br>
<strong> 5) </strong> የጥቃት ግንኙነቶችን ይገልጻል<br>
<strong> 6) </strong> በጽሁፉ ውይም በምስሉ  ውስጥ የሚያንቋሽሹ ወይም የዘር ስድብ ቃላትን ይጠቀማል<br>
<strong> 7) </strong> ለመጉዳት ወይም ጉዳት ለማነሳሳት በማሰብ የማጥላላት ቃላትን ይጠቀማል<br>
<strong> 8) </strong>  የጾታ አቀንቃኝ ወይም የዘር ስድብ ይጠቀማል።<br>
<strong> 9) </strong> አናሳዎችን ያጠቃል።<br>
<strong> 10) </strong> አናሳን ወይም ሌላ ዘርን ወይም ሃይማኖትን ዝም ለማሰኘት ይፈልጋል።<br>
<strong> 11) </strong> አናሳዎችን ይወቅሳል (በጥሩ መሠረት ያለ ክርክር)።<br>
<strong> 12) </strong> የጥላቻ ንግግርን ወይም የአመፅ ወንጀልን ያስተዋውቃል፣ ግን በቀጥታ አይጠቀምም።<br>
<strong> 13) </strong> አናሳዎችን ይወቅሳል እና የገለባ ሰው ክርክር ይጠቀማል።<br>
<strong> 14) </strong> በአሉታዊ መልኩ አናሳዎችን ይመለከታል።<br>
<strong> 15) </strong> የሆነን ግለሰብ ወይም ቡድንን ለማናደድ የጥላቻ ንግግሮችን ይጠቀማል።<br>
               
<strong> 16) </strong> የአንድን ብሄረሰብ ሆነ ጎሳን ለማንቆሸሽ ወይም ታሪክን ለማበላሸት የጥላቻ ንግግርን ይጠቀማል።<br>

               
               
 
               

 </div>
                     
           
                
         
              </div>
              
              
              
              <div class="container">
              
                         
                    <?php 
                    
                            $counter=0;
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
                      
                	$num_per_page=01;
                	if(isset($_GET["page"]))
                	{
                		$page=$_GET["page"];
                	}
                	else
                	{
                		$page=1;
                	}
                	$start_from=($page-1)*$num_per_page;
                	$sql="select * from example_dataset ";
                	$rs_result = mysqli_query($con, $sql);
                ?>
                      
                            <?php 
                                    if(mysqli_num_rows($rs_result) > 0)
                                    {
                                        foreach($rs_result as $student)
                                        {
                                            
                                            
                                            if($counter==0){
                                                $counter=1;
                                  ?>
              
              
              
              
                  <div class="row">
                    <div  class="col alert alert-info" style="min-height: 10%; width:45%; margin-right:2%">
                     
                                    <p>
                                        <img src="../admin/image/guidline/<?php echo $student['image_name']; ?>" class="img-fluid"  id ="imageId" autofocus></p>
                                 
                                        
                                        
                                <b><?php echo $student['image_lable']; ?></b>
                                 
                     
                     
                    </div>
                    <?php 
                                            }else{
                                                $counter=0;
                    
                    ?>
                    <div class="col alert alert-info" style="margin-right:2%" >
                     
                     
                     
                                    <p style="text-align:'center';">
                                        <img src="../admin/image/guidline/<?php echo $student['image_name']; ?>" class="img-fluid" id ="imageId" autofocus></p>
                                  
                                <b><?php echo $student['image_lable']; ?></b>
                     
                    </div>
                  </div>
                
                <br>
                <br><br>
                
                     <?php    
                                            }
                        }
                         }
                                
                        ?>    
                    
                </div>
              
              
              
              
              
              
              
              
              
              
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="call-to-action" style="margin-top: -20px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              
              
              
  
   <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form   style="margin-top: -100px;" enctype="multipart/form-data" action="upload_image.php" method="POST">
                   
                


                </form>
            </div>
        </div>
    </div>
  
              
              
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="blog-posts grid-system">
    </section>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2023 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
