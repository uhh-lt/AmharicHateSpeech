
  <?php
  session_start();
if(!isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page 
    echo "<script> window.location.assign('../login_page.php'); </script>";
} 
?>  
<?php 
    if(isset($_POST['Submit']))
    {
        echo "hhhhhhh";
        $lable = $_POST['labling'];
        $username = $_SESSION['username'];
        $image_id = $student['id'];
        $status = 0;
        

    $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");

        
    	$query = mysqli_query($con, "SELECT * FROM annotate_data WHERE  image_id='$image_id' and username='$username'");
			$row = mysqli_fetch_array($query);
			$num_row = mysqli_num_rows($query);
			
			if ($num_row > 0) 
				{	
                   echo "You are annotated this dataset, so select the next image...";
				}
			else
				{
            		$sql = "INSERT INTO annotate_data (username, image_id, lable, status) VALUES ('$username', '$image_id', '$lable', '$status')";
            		if ($con->query($sql) === TRUE) {
            		    echo "Dataset annotated Database Successfully!";
            		    
                   echo "<script> window.location.assign('index.php'); </script>";
            		    } 
            		else {
            		    echo "Error annotating Data: " .$conn->error;
            	     	}
				}
				
				
				
		$conn->close();
    }
?>

