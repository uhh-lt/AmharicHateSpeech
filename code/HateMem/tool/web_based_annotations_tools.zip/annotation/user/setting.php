
  <?php
  session_start();
if(isset($_SESSION['username'])) {
    // show the user's dashboard or redirect to a protected page
} else {
    echo "<script> window.location.assign('../login_page.php'); </script>";
}
?>  


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $(document).ready(function(){
$('.pass_show').append('<span class="ptxt">Show</span>');  
});
  

$(document).on('click','.pass_show .ptxt', function(){ 

$(this).text($(this).text() == "Show" ? "Hide" : "Show"); 

$(this).prev().attr('type', function(index, attr){return attr == 'password' ? 'text' : 'password'; }); 

});  
</script>
    <title>Annotation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->
<style>
    .pass_show{position: relative} 
    
    .pass_show .ptxt { 
    
    position: absolute; 
    
    top: 50%; 
    
    right: 10px; 
    
    z-index: 1; 
    
    color: #f36c01; 
    
    margin-top: -10px; 
    
    cursor: pointer; 
    
    transition: .3s ease all; 
    
    } 
    
    .pass_show .ptxt:hover{color: #333333;} 
</style>
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link " href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href=" guidline.php">Guidline</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>

    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="alert alert-success text-content">
                <h4>you can change your password(የይለፍ ቃልህን መቀየር ትችላለህ)</h4> 
         
              </div>
            </div>
          </div>
        </div>
        <?php
        if(isset($_POST['ChangePassword'])){
                $currentpassword = $_POST['currentpassword'];
                $newpassword = $_POST['newpassword'];
                $confirmpassword = $_POST['confirmpassword'];
                $username = $_SESSION['username'];
            
                if ($newpassword != $confirmpassword) {
                    echo "New passwords do not match. Please try again.";
                } else {
                    
        $conn = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
                   
            
                    $query = "SELECT * FROM register WHERE username = '$username' AND password = '$currentpassword'";
                    $result = mysqli_query($conn, $query);
                    if (mysqli_num_rows($result) == 1) {
                        $query = "UPDATE register SET password = '$newpassword' WHERE username = '$username'";
                        mysqli_query($conn, $query);
                        ?>
                         <div class="alert alert-success">
                            <strong>Password updated successfully !!!</strong> 
                         </div>
                        <?php
                    } else {?>
                         <div class="alert alert-warning">
                             <strong>Incorrect current password. Please try again.!</strong>.
                          </div>
                   <?php }
                }
        }
        
        ?>
        <div class="container"  style="float: left; margin-left:11%">
        	<div class="row">
    		    <div class="alert alert-info  col-sm-6" style="float: left">
    		     <form action="setting.php" method="POST">
        		    <div class="form-group pass_show"> 
                        <input type="password" value="" class="form-control" placeholder="Current Password(የአሁኑ ሚስጥራዊ ቁልፍ)" name="currentpassword"> 
                    </div> 
                    <div class="form-group pass_show"> 
                        <input type="password" value="" class="form-control" placeholder="New Password(አዲስ የይለፍ ቃል)" name="newpassword"> 
                    </div> 
                    <div class="form-group pass_show"> 
                        <input type="password" value="" class="form-control" placeholder="Confirm Password(የይለፍ ቃል አረጋግጥ)" name="confirmpassword"> 
                    </div> 
                    <div class="btn btn-info ">
                        <input type="submit" value="ChangePassword(መለወጥ)"  name="ChangePassword"> 
                    </div> 
                    
                </form>
            	</div>
            	 <div class="alert alert-info col-sm-4" style="float: right; margin-left:50px;">
    		        
                    <h4>You can Exit from Annotation.(ከማብራሪያው መውጣት ይችላሉ።)</h4> <br>
        		    <label>Click logout button to exit.(ለመውጣት የመውጣት ቁልፍን ጠቅ ያድርጉ።)</label><br>
                       <a href="../logout.php" class="btn btn-info btn-lg">
                         <span class="glyphicon glyphicon-log-out"> </span> Logout(ውጣ)
                       </a>
                
        	</div> 
        	</div>
        </div>
       
        
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="call-to-action" style="margin-top: -20px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              
              
              
  
   <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form   style="margin-top: -100px;" enctype="multipart/form-data" action="upload_image.php" method="POST">
                   
                


                </form>
            </div>
        </div>
    </div>
  
              
              
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="blog-posts grid-system">
    </section>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2023 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
