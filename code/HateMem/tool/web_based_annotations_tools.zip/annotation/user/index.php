
  <?php
  session_start();
  
if(!isset($_SESSION['username'])) {
    echo "<script> window.location.assign('../login_page.php'); </script>";
}

$username =$_SESSION['username'];
?>
<script>
    window.onload = function() {
        var imageElement = document.getElementById("imageId");
        window.scrollTo(0, imageElement.offsetTop);
    }
</script>

<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
    
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    
    
    
    
    
    
    
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }
</script>

<style>
    
    .responsive-image {
   max-width: 500px;
   max-height: 500px;
   width: auto;
   height: auto;
}

</style>
    <title>Annotation Page</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="csss/fontawesome.css">
    <link rel="stylesheet" href="css/templatemo-stand-blog.css">
    <link rel="stylesheet" href="css/owl.css">
<!--

TemplateMo 551 Stand Blog

https://templatemo.com/tm-551-stand-blog

-->
  </head>

  <body>

    <!-- ***** Preloader Start ***** -->
    <div id="preloader">
        <div class="jumper">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>  
    <!-- ***** Preloader End ***** -->

    <!-- Header -->
    <header class="">
      <nav class="navbar navbar-expand-lg">
        <div class="container">
          <a class="navbar-brand" href="index.html"><h2>Annotation Page<em>.</em></h2></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item">
                <a class="nav-link active" href="index.php">Home
                  <span class="sr-only">(current)</span>
                </a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href=" guidline.php">Guidline</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="setting.php">Setting</a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </header>


    <!-- Page Content -->
    <!-- Banner Starts Here -->
    <div class="heading-page header-text">
      <section class="page-heading">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
              <div class="text-content">
           
                  
                  
                  <div class="alert alert-info">
                    <h4>   <strong> የማብራሪያውን መጀመር ትችላለህ</strong></h4>
                    </div>
                
                <h5 style="color:black;"> 
                
         
                     <div class="alert alert-info">
                      <strong>መረጃ!</strong> የመረጃ ቋቱን ከማብራራትዎ ወይም መልሶን ከመስጠትዎ በፊት እባኮትን ምስሉን ይመልከቱ እና የምስሉን ዐውደ ትርጉም እና በምስሉ ላይ ያለውን ጽሑፍ ይረዱ ከዛም በሃላ ትክክል የሆነውን ይምረጡ። 
                    </div>
         
         
         
         
              </div>
              <div class="text-content">
                <div align="center">
                    
                    
                             
                    <?php 
                    
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
                      
                	$num_per_page=01;
                	if(isset($_GET["page"]))
                	{
                		$page=$_GET["page"];
                		if($page==0){
                		    $page=1;
                		}
                	}
                	else
                	{
                		$page=1;
                	}
                	$start_from=($page-1)*$num_per_page;
                	$sql="select * from dataset where  max_no_annotation>=1 and annotator_one != '".$username."' and annotator_two != '".$username."' and annotator_three != '".$username."' limit $start_from,$num_per_page";
                	$rs_result = mysqli_query($con, $sql);
                	$manage_visibility=mysqli_num_rows($rs_result);
                    
                                    if(mysqli_num_rows($rs_result) > 0)
                                    {
                                        foreach($rs_result as $student)
                                        {
                                            $_SESSION['max_no_annotation']=$student['max_no_annotation'];
                                            $ex=$student['image_name'];
                                            $ids=$student['id'];
                                            
                                                      $id=$id+1;
                                                      $a=explode(".",$ex);
                                                      $id=$ids.".".$a[1];
                            
                                            
                                  ?>
                                  <img src="../admin/image/<?php echo $id; ?>" class="img-fluid" id="imageId" autofocus>
                                  
                                    <?php        $_SESSION['image_id']=$student['id'];
                                    
                                    
                        }
                         }   else{
                             ?>
                                 <div class="alert alert-success">
                                    <strong>Success!</strong> Thank you very much for supporting, you finished all dataset!!!
                                  </div>
                             <?php
                             
                         }   
                        ?>  
                        
      


                    
                </div
                
                
                <?php
                if ($manage_visibility>0){
                ?>
                
                        <div class="container mt-3" align="center" >
                        
                             <div class="alert alert-info">
                               <h3>  <strong>አማራጩን ይምረጡ</strong></h3> 
                              </div>
                              
                           <form  action="" method="POST" >
                               <?php 
    if(isset($_POST['Submit']))
    {
        
        $lable = $_POST['labling'];
        $username = $_SESSION['username'];
        $image_id =  $_SESSION['image_id'];
        $status = 0;
        if($lable!=""){
        
    $query = mysqli_query($con, "SELECT * FROM annotate_data WHERE  image_id='$image_id' and username='$username'");
			$row = mysqli_fetch_array($query);
			$num_row = mysqli_num_rows($query);
			
			
			if ($num_row > 0) 
				{	
				    
				    
                    echo "You are annotated this dataset, so select the next image...";
				}
			else
				{
				    
            		$sql = "INSERT INTO annotate_data (username, image_id, lable, status) VALUES ('$username', '$image_id', '$lable', '$status')";
            		if ($con->query($sql) === TRUE) {
            		    
            		    $max_no_annotations= $_SESSION['max_no_annotation']-1;
            		    
            		                if($_SESSION['max_no_annotation'] == 3){
            		                    
            		                  $updt =  "UPDATE dataset SET annotator_one = '$username'  , max_no_annotation=$max_no_annotations where id = $image_id";
            		                   mysqli_query($con,$updt);
            		                   
            		                }else if($_SESSION['max_no_annotation'] == 2){
            		                    
            		                  $updt =  "UPDATE dataset SET annotator_two = '$username', max_no_annotation=$max_no_annotations  where id= $image_id";
            		                   mysqli_query($con,$updt);
            		                }else{
            		                    
            		                  $updt =  "UPDATE dataset SET annotator_three = '$username'  , max_no_annotation=$max_no_annotations where id = $image_id";
            		                   mysqli_query($con,$updt);
            		                }
            		    
            		    
            		    
            		            $pr_queryd = "select * from dataset where  max_no_annotation>=1 and annotator_one != '".$username."' and annotator_two != '".$username."' and annotator_three != '".$username."' ";
                                $pr_resultd = mysqli_query($con,$pr_queryd);
                                $total_recordd = mysqli_num_rows($pr_resultd );
            		 
                    		    if ($total_recordd<=$page){
                    		        $page=$total_recordd-1;
                    		    }
                    		    
                    		    
                   echo "<script> window.location.assign('index.php?page=".$page."'); </script>";
            		    } 
            		else {
            		     echo "Error annotating Data: " .$conn->error;
            	     	}
				}   
        
        
    }else{?>
        <div class="alert alert-warning">
                                    <strong>Sorry!</strong> Please select the option in the drop down before submting!!!
                                  </div>
                                  <?php
    }
    }
          
 ?>
                            <div class="alert alert-info">
                                 <select name="labling"  class="alert alert-dark dropdown-toggle" data-bs-toggle="dropdown"  align="center" >
                                      <option value="">የመለያ ምድብ ይምረጡ</option>
                                      <option value="hate speech">የጥላቻ ንግግር</option>
                                      <option value="normal speech">የጥላቻ ንግግር አይደለም</option>
                                     <!-- <option value="dont know">መለየት አልቻልኩም</option>-->
                                    </select>
                                    <input type="submit"  class="alert alert-dark" title="Submit" name="Submit" value="ላክ"></input>
                                    
                                    <button type="button"  class="alert alert-info" disabled>ለማብራራት የቀረው = <?php echo $_SESSION['max_no_annotation'];?></button>  
                            </div>
                            <?php
                            
        $con = mysqli_connect("localhost","id20913613_meleayi","meleA@1212","id20913613_annotation");
                                    

                                    $queryy = "SELECT * FROM dataset";
                                    $query_runn = mysqli_query($con, $queryy);
                                    $total_number_of_dataset=mysqli_num_rows($query_runn) ;
                                  $usrnm=$username;
                                 
                                     $queryys = "SELECT * FROM annotate_data where username='$usrnm'";
                                    $query_runns = mysqli_query($con, $queryys);
                                    $total_number_of_annotated_dataset=mysqli_num_rows($query_runns) ;
                                    
                                    $percent =$total_number_of_annotated_dataset/$total_number_of_dataset*100;
                                    
                                 if($percent==0){
                                     
                                 }else{?>
                                     
                               
                                  
                                   <div class="progress" style="height:30px;" >
                                    <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width:<?php echo "$percent"; ?>%">
                                     <?php echo $percent; ?> Processing ...
                                    </div>
                                  </div>
                                   
                                  
                                  
                                    <?php
                                     
                                 }
                                  ?>
                                  
                                  
                                    
                                    
                            </form>        
                        </div>
                <div style="margin-top:20px;" align="center" class="alert alert-info">
                    
           
           
           
                        <?php 
                        
                                $pr_query = "select * from dataset where  max_no_annotation>=1 and annotator_one != '".$username."' and annotator_two != '".$username."' and annotator_three != '".$username."' ";
                                $pr_result = mysqli_query($con,$pr_query);
                                $total_record = mysqli_num_rows($pr_result );
                                
                                $total_page = ceil($total_record/$num_per_page);
                
                
                                if($page>1)
                                {
                                    echo "<a href='index.php?page=".($page-1)."' class='btn btn-danger'>ቀዳሚ</a>";
                                }
                                
                                if($page-2>0){
                           echo "<a href='' class='btn btn-secondary'>...</a>";

                                }
                                
                                for($i=2;$i>=1;$i--)
                                {
                                    if($i>=1){
                                     $page_dis=$page-$i;
                                     if($page_dis<0){
                                         $page_dis=0;
                                     }else{
                                  echo "<a href='index.php?page=".$page_dis."' class='btn btn-secondary'>$page_dis</a>";
                                    }}
                                }
                                
                                
                                
                           echo "<a href='index.php?page=".$page."' class='btn btn-primary  active'>$page</a>";
                


                                for($i=1;$i<$total_page;$i++)
                                {
                                    if($i<3){
                                     $page_dis=$page+$i;
                                     if($page_dis>$total_page){
                                         $page_dis=$total_page;
                                     }else{
                                  echo "<a href='index.php?page=".$page_dis."' class='btn btn-secondary'>$page_dis</a>";
                                    }}
                                }
                
                
                      if($page+2<$total_page){
                           echo "<a href='' class='btn btn-secondary'>...</a>";

                                }
                                
                                if($i>$page)
                                {
                                    echo "<a href='index.php?page=".($page+1)."' class='btn btn-danger'>ቀጣይ</a>";
                                }
                        
                        ?>

                 
                </div>
         
                        
          <?php
          
          
                }
                
                ?>
                        
    
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
    
    <!-- Banner Ends Here -->

    <section class="call-to-action" style="margin-top: -20px;">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="main-content">
              
              
              

  
              
              
            </div>
          </div>
        </div>
      </div>
    </section>


    <section class="blog-posts grid-system">
    </section>

    
    <footer>
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <ul class="social-icons">
              <li><a href="https://www.facebook.com/melese.aychlie">Facebook</a></li>
              <li><a href="https://twitter.com/JigarMelese">Twitter</a></li>
              <li><a href="https://t.me/Mymistakeiss">Telegram</a></li>
              <li><a href="https://www.youtube.com/@meleseayichlie5645">YouTube</a></li>
            </ul>
          </div>
          <div class="col-lg-12">
            <div class="copyright-text">
              <p>Copyright 2023 @Mele.
                    
                 | Design: <a rel="nofollow" href="meleseayichlie.000webhostapp.com" target="_parent">Contact Me</a></p>
            </div>
          </div>
        </div>
      </div>
    </footer>


    <!-- Bootstrap core JavaScript -->
    <script src="css/jquery.min.js"></script>
    <script src="css/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="js/custom.js"></script>
    <script src="js/owl.js"></script>
    <script src="js/slick.js"></script>
    <script src="js/isotope.js"></script>
    <script src="js/accordions.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>
